/*     *********************************
//     *    Matrix Multiply Project    *
//     *                               *
//     *********************************

//     ** MAIN PROGRAM  **


//     *************************************************
//     ** Any changes you make to this code must      **
//     ** maintain the correctness of the matrix      **
//     ** multiply computed by the original version.  **
//     **                                             **
//     ** You may assume m = n = k for your matrices  **
//     *************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <time.h>
#include <sys/resource.h>

double **allocatematrix(int nrl,int nrh,int ncl,int nch);
int freematrix(double **m, int nrl,int nrh,int ncl,int nch);
void nerror(char *error_text);
double second(int nmode);

int main(int argc, char** argv)  {
 
      int l,m,n,k;
      int i,j;
      double temp;
      double **A, **B, **C;
      double tstart, tend;

     /*  ****************************************************
     //  * The following allows matrix parameters to be     *
     //  * entered on the command line to take advantage    *
     //  * of dynamically allocated memory.  You may modify *
     //  * or remove it as you wish.                        *
     //  ****************************************************/

    if (argc != 4) {
       nerror("Usage:  <executable> <m-value> <n-value> <k-value>");
     }
      m = atoi(argv[1]);
      n = atoi(argv[2]);
      k = atoi(argv[3]);
     
      /* *********************************************************
      // * Call the allocmatrix() subroutine to dynamically allocate *
      // * storage for the matrix sizes specified by m, n, and k *  
      // *********************************************************/

      A=allocatematrix(1,m,1,k);
      B=allocatematrix(1,k,1,n);
      C=allocatematrix(1,m,1,n);

      /* *********************************************************
      //  * Initialize matrix elements so compiler does not      *
      //  * optimize out                                         *
      // *********************************************************/

      for(j=1;j<=k;j++) {
        for(i=1;i<=m;i++) {
          A[i][j] = i * 3.2  + j * 2.21;
        }
      }

      for(j=1;j<=n;j++) {
        for(i=1;i<=k;i++) {
          B[i][j] = j * 1.3  + j * 3.1;
        }
      }

      for(j=1;j<=n;j++) {
        for(i=1;i<=m;i++) {
          C[i][j] = 0.0;
        }
      }
          
      /* **********************************
      // * Perform simple matrix multiply *
      // **********************************/
	  tstart = second(RUSAGE_SELF);
      for(j=1;j<=n;j++) {
        for(l=1;l<=k;l++) {
          for(i=1;i<=m;i++) {
            C[i][j] = C[i][j] + B[l][j]*A[i][l];
          }
        }
      }
	  tend = second(RUSAGE_SELF);
      /* **************************************************
      // * Print out results for testing only    *
      // *                         *
      // **************************************************/

/*      fprintf(stdout, "Here is the matrix A:\n\n");
      for(i=1;i<=m;i++) {
        for(j=1;j<=k;j++) {
          fprintf(stdout, "%10.2f ",A[i][j]);
        }
        fprintf(stdout, "\n");
      }
      fprintf(stdout, "Here is the matrix B:\n\n");
      for(i=1;i<=k;i++) {
        for(j=1;j<=n;j++) {
          fprintf(stdout, "%10.2f",B[i][j]);
        }
        fprintf(stdout, "\n");
      }
      fprintf(stdout, "Here is the matrix C:\n\n");
      for(i=1;i<=m;i++) {
        for(j=1;j<=n;j++) {
          fprintf(stdout, "%10.2f",C[i][j]);
        }
        fprintf(stdout, "\n");
      }

	  fprintf(stdout, "The total CPU time is: %f seconds \n\n", tend - tstart);
*/
      /* **************************************************
      // * Free the memory allocated for the matrices  *
      // *                         *
      // **************************************************/
      
      freematrix(A, 1,m,1,k);
      freematrix(B, 1,k,1,n);
      freematrix(C, 1,m,1,n);
}

double **allocatematrix(int nrl,int nrh,int ncl,int nch)
{
  double **m;
  int i;

  m=(double **) malloc((unsigned)(nrh-nrl+1)*sizeof(double*));

  if (!m) nerror("allocation failure 1 in matrix()");

  m -= nrl;

  for(i=nrl;i<=nrh;i++) {
    m[i]=(double *) malloc((unsigned)(nch-ncl+1) * sizeof(double));
    if (!m[i]) nerror("allocation failure 2 in matrix()");
    m[i] -= ncl;
  }
  return m;
}

int freematrix(double **m, int nrl,int nrh,int ncl,int nch)
{
    int i;

    free((double *) (m[nrl-1]));

    for (i = nrh; i >= nrl; i--)
       free((double *) (m[i] + ncl)), m[i]=NULL;
    
    free((double *) (m + nrl-1)), m=NULL;
    return 1; 
}

void nerror(char *error_text)
{
  void exit();
  fprintf(stderr, "Run-time error...\n");
  fprintf(stderr,"%s\n",error_text);
  fprintf(stderr,"Exiting...\n");
  exit(1);
}

double second(int nmode)
  /****************************************************************************
 *              Returns the total cpu time used in seconds.
 ****************************************************************************/
{
  struct rusage buf;
  double temp;
  
  getrusage( nmode, &buf );
  
  /* Get system time and user time in micro-seconds.*/
  temp = (double)buf.ru_utime.tv_sec*1.0e6 + (double)buf.ru_utime.tv_usec +
    (double)buf.ru_stime.tv_sec*1.0e6 + (double)buf.ru_stime.tv_usec;
  
  /* Return the sum of system and user time in SECONDS.*/
  return( temp*1.0e-6 );
}                              

#if 0
void SetSeed(int flag)
/* if flag == 1, set fixed random seed
// else 
//       set random seed based on current time */
{
  unsigned short seed[3];
  long ltime;
  
  if (flag)
  {
  seed[0] = (unsigned short) 0;
  seed[0] = (unsigned short) 1 ;
  seed[0] = (unsigned short) 2;	
  seed48(seed);

  return;
  }

  time(&ltime);
  seed[0] = (unsigned short)ltime;
  
  time(&ltime);
  seed[1] = (unsigned short)ltime;
  
  time(&ltime);
  seed[2] = (unsigned short)ltime;
  
  seed48(seed);            
}

double rand_gen(double fmin, double fmax)
{
  return fmin + (fmax - fmin) * drand48();
}
#endif
